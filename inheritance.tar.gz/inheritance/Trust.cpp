#include <iostream>
#include "Trust.h"

Trust_Account::Trust_Account(std::string name, double balance, double interest)
    :Savings_Account (name, balance, interest) {
}

bool Trust_Account::deposit(double amount, double interest) {

    if (amount >= 5000) {
        amount += 50;
    }
    amount += amount * (interest / 100);
    bool deposit(double amount);
}

bool Trust_Account::withdraw(double balance, double amount) {
    
}